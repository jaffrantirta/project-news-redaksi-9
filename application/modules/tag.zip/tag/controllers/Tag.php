<?php

class Tag extends MX_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Data');
        $this->load->model('DataMenuManager');
        $this->numOfContentsPerPage = 20;
    }

    

    public function index($any)
    {
        $id=str_replace("-", " ", $any);
        $data['media'] = $this->Data->getAllData('media');
        $data['menumanager'] = $this->DataMenuManager->getAllData('menumanager');
        $data['region'] = $this->Data->getAllData('region');
        $data['pengaturan'] = $this->Data->getAllData('pengaturan');
        $data['slider'] = $this->Data->getkritik('5','0','berita');
        $data['peristiwa'] = $this->Data->getkategori('5','0','berita', '19');
        $data['politik'] = $this->Data->getkategori('5','0','berita', '20');
        $data['kriminal'] = $this->Data->getkategori('5','0','berita', '21');
        $data['birokrasi'] = $this->Data->getkategori('5','0','berita', '22');
        $data['ekonomi'] = $this->Data->getkategori('5','0','berita', '31');
        $data['baru'] = $this->Data->getkritik('6','5','berita');
        $data['bannerDM04'] = $this->Data->getBannerPosition(null, null, 'banner', 'DM04');
        $data['bannerDM02'] = $this->Data->getBannerPosition('1', '0', 'banner', 'DM02');
        $data['bannerDM01'] = $this->Data->getBannerPosition('1', '0', 'banner', 'DM01');
        $data['bannerDM03'] = $this->Data->getBannerPosition('1', '0', 'banner', 'DM03');
        $data['bannerDM05'] = $this->Data->getBannerPosition('1', '0', 'banner', 'DM05');
        $data['bannerDM06'] = $this->Data->getBannerPosition('1', '0', 'banner', 'DM06');
        $data['tv'] = $this->Data->getkritik('6','0','tv');
        $data['about'] = $this->Data->getAllData('about');
            
            
            $this->initializepagination(base_url("tag/index/$id/"),
            'berita',
            'Data',
            $this->Data->countSearchData(
                'berita',
                null,
                null,
                'tags LIKE \'%' . $id . '%\'')
        );
            $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
            $data['datas'] = $this->Data->searchData($this->numOfContentsPerPage,$page,'berita',null,null,'tags LIKE \'%' . $id . '%\'');
            $data['page'] = $page;
            $data['title'] = $this->Data->getSpecificData('kategori', array('id' => $id));
            $this->template->set_template('frontend/template');
    
            $this->template->stylesheet->add(base_url() . "public/css/index.css");
            $this->template->header->view('frontend/partials/header', $data);
            $this->template->content->view('tag/baca', $data);
            $this->template->footer->view('frontend/partials/footer');
            $this->template->sidebar->view('frontend/partials/sidebar');
            $this->template->publish();
    }
    
    
    



}