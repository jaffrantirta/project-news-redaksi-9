  <?php

  function format_date_in($option_format, $date){

		list($yyyy, $mm, $dd) = explode('-', $date);

		$ary_month = array("01" => "Januari","02" => "Februari","03" => "Maret","04" => "April","05" => "Mei","06" => "Juni","07" => "Juli","08" => "Agustus","09" => "September","10" => "Oktober","11" => "November","12" => "Desember",);

		

		foreach($ary_month as $key => $val){

			if($key==$mm){$mm = $val;}

		}			

		switch($option_format){

			case "1"	:

				$date = $mm." ".$dd.", ".$yyyy;

				break;

			case "2"	:

				$date = $dd." ".$mm." ".$yyyy;

				break;	

		

		}

		return 	$date;	

	}
  ?>

<div class="container" style="padding-top:20px">
    <div class="cp-news-grid-style-5">
        <div class="col-sm-8">		
            <div class="cp-inner-main-banner top-banner-bg1" style="background-color: white;padding-bottom: 10px;padding-top: 0px;margin-bottom:unset">
        		<div class="col-md-12 no-padding">
    				<div class="col-md-6 col-xs-6" style="padding-top:10px">
    			        <h1 style="color: black;float: left;font-size:30px">#<?= str_replace("-", " ", $this->uri->segment(2)) ?></h1>
    				</div>
    				<div class="col-md-6 col-xs-6">
    				    <ul class="breadcrumb" style="color: black;float: right;">
    				        <li><a href="<?php echo base_url(); ?>" style="color: black;">Home</a></li>
    				        <li> Tags</li>
    					    <li> <?= str_replace("-", " ", $this->uri->segment(2)) ?></li>
    			        </ul>
    				</div>
    				<div class="col-md-12"><div class="col-md-12" style="border-bottom: 1px solid #ddd;"></div></div>
        		</div>
        	</div>	
			<div class="panel panel-default">	
                <div class="panel-body" style="background:white">
                    <?php
    					if (isset($datas)){
                            $index = 1;
                            if(isset($page)&&$page!=0)
                                $index = $index+$page;
            				foreach ($datas as $d_n){
                                $region= $this->Data->getSpecificData('region', array('id' => $d_n->id_region));
                                $url_n 		= base_url().'read/'.$d_n->id.'/'.getPermalink($d_n->title);?>
        						<div class="cp-news-list">
        							<ul class="row">
        								<li class="col-md-5 col-sm-5">
        									<div class="cp-thumb">
        											<img alt src="<?php echo base_url().'uploads/berita/'.$d_n->img; ?>">
        									</div>
        								</li>
        								<li class="col-md-7 col-sm-7">
        									<div class="cp-post-content">
        										<h3>
        											<a href="<?= $url_n; ?>">
        												<?= $d_n->title."\n"; ?>
        											</a>
        										</h3>
        										<ul class="cp-post-tools">
        											<li>
        												<i class="fa fa-clock-o"></i> 
        												<?= format_date_in(2, substr($d_n->date, 0, 10)); ?>
        											</li>
        											<li>
        												<i class="fa fa-map-marker"></i>
        												<?= $region->title; ?>
        											</li>
        										</ul>
        										<p><?= substr(strip_tags($d_n->content), 0, 150)."..."; ?></p>
        									</div>
        								</li>
        							</ul>
        						</div>
                                <?php
                                $index++;
                            }
    					}
                    ?>
                    <div class="pagination-holder">
    					<nav>
                        <?php echo $this->pagination->create_links(); ?>
                        <?php echo validation_errors(); ?>
                        <?php if (isset($result)) echo $result; ?>
                        </nav>
                    </div>
                </div>
			</div>
		</div><!-- /.Tengah -->
				  
				  
                      
                     